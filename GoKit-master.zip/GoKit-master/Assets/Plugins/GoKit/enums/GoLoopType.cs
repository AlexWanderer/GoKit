using UnityEngine;
using System.Collections;



public enum GoLoopType
{
	RestartFromBeginning,
	PingPong
}